
import { Link, Routes, Route, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import SellerHome from '../components dotnet/SellerHome';
import ConsumerHome from '../components dotnet/ConsumerHome';
import AdminHome from '../components dotnet/AdminHome';
import Registration from '../components dotnet/Registration';
import LoginPage from '../components dotnet/LoginPage';
import pic1 from '../images/overview.png';
import AddShop from '../components dotnet/SellerPage/AddShop';
//isHomePage ? `url(${pic1})` : 'none'
function Home() {
  const mystate = useSelector((state) => state.logged);
  const location = useLocation();

  // Determine if the current route is the home page
  const isHomePage = location.pathname === '/';

  return (
    <div className="App" style={{ minHeight: '', backgroundColor: '#f8f9fa' }}>
      {/* <div
        style={{
          backgroundImage: isHomePage ? `url(${pic1})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
          minHeight: '100vh',
        }}
      > */}
      
          <div
          style={{
            backgroundImage: isHomePage ? `url(${pic1})` : 'none',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            minHeight: isHomePage?'100vh':'0vh',
          }}
        >
            {!mystate.loggedIn && (
          <nav className='navbar navbar-expand-sm mb-3' style={{ backgroundColor: 'skyblue' }}>
            <div className="container-fluid">
              <h3>Agada</h3>
              <ul className="navbar-nav ms-auto"> {/* ms-auto will push the links to the right */}
                <li className="nav-item">
                  <Link to="/" className='nav-link px-3'>Home</Link>
                </li>
                <li className='nav-item'>
                  <Link to="/login" className='nav-link px-3'>Login</Link>
                </li>
                <li className='nav-item'>
                  <Link to="/registration" className='nav-link px-3'>Signup</Link>
                </li>
                <li className='nav-item'>
                  <Link to="/contact" className='nav-link px-3'>Contact Us</Link>
                </li>
              </ul>
            </div>
          </nav>
        
        )}
{/* 
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/adminhome" element={<AdminHome />} />
          <Route path="/consumerhome" element={<ConsumerHome />} />
          {/* <Route path="/sellerhome" element={<SellerHome />} /> */}
        {/* </Routes>  */}
      {/* </div> */}
      </div>
    </div>
    
  );
}

export default Home;
