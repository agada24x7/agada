import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useSelector } from 'react-redux';
// import SellerHome from './components dotnet/SellerHome';
import Home from './Home/Home';
import MainSeller from './components dotnet/SellerPage/MainSeller.js';
import AddShop from './components dotnet/SellerPage/AddShop.js';
import Discounts from './components dotnet/SellerPage/Discounts.js';
import AddProduct from './components dotnet/SellerPage/Inventory/AddProduct.js';
import DeleteProduct from './components dotnet/SellerPage/Inventory/DeleteProduct.js';
import ViewProduct from './components dotnet/SellerPage/Inventory/ViewProduct.js'; // Fixed the name
import UpdateProduct from './components dotnet/SellerPage/Inventory/UpdateProduct.js'; // Fixed the import path
// import Logout from './components dotnet/Logout';
import SellerHome from './components dotnet/SellerHome';
import ConsumerHome from './components dotnet/ConsumerHome';
import AdminHome from './components dotnet/AdminHome';
import Registration from './components dotnet/Registration';
import LoginPage from './components dotnet/LoginPage';

function App() {
  const mystate = useSelector((state) => state.logged);

  return (
    <div className="App">
      <Home />
 
      <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/adminhome" element={<AdminHome />} />
          <Route path="/consumerhome" element={<ConsumerHome />} />
          {/* <Route path="/sellerhome" element={<SellerHome />} />  */}
        <Route path="/sellerhome/*" element={<SellerHome />}>
          <Route path="sellerdashboard" element={<MainSeller />} />
          <Route path="addshop" element={<AddShop />} />
          <Route path="discounts" element={<Discounts />} />
          <Route path="inventory/addproduct" element={<AddProduct />} />
          <Route path="inventory/deleteproduct" element={<DeleteProduct />} />
          <Route path="inventory/updateproduct" element={<UpdateProduct />} />
          <Route path="inventory/viewproduct" element={<ViewProduct />} />
          {/* <Route path="logout" element={<Logout />} /> */}
        </Route>
      </Routes>
    </div>
  );
}

export default App;
