import { configureStore } from "@reduxjs/toolkit";
import loggedReducer from "./components dotnet/slice";

// Configure the store with the correct reducer key
export default configureStore({
    reducer: {
        logged: loggedReducer
    }
});
