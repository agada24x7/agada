import React, { useState, useEffect } from 'react';
import "../styles/styles.css"

export default function ConsumerHome()
{
        const [shops, setShops] = useState([]);
        const [selectedShop, setSelectedShop] = useState('');
        const [prodname, setProdname] = useState('');
        const [products ,setProducts] = useState([]);
        const [quantity, setQuantity] = useState(1);

        useEffect(() => {
            const fetchShops = async () => {
                try {
                    const response = await fetch('http://localhost:8080/shops/getshops');
                    const data = await response.json();
                    setShops(data);
                } catch (error) {
                    console.error('Error fetching shops', error);
                }
            };
    
            fetchShops();
        }, []);

    const handleIncrement = () => {
        setQuantity(quantity + 1);
    };
        
    const handleDecrement = () => {
        setQuantity(Math.max(quantity - 1, 1));
    };

    const handleShopChange = (e) => {
        setSelectedShop(e.target.value);
        setProducts([]); // Clear the product list when the shop changes
    };

    const handleSearch = async (e) => {
        e.preventDefault();
        if (selectedShop === '') {
            alert('Please select a shop first.');
            return;
        }

        try {
            const response = await fetch(`http://localhost:8080/search?shId=${selectedShop}&prodname=${prodname}`);
            const data = await response.json();
            setProducts(data);
        } catch (error) {
            console.error('Error searching products', error);
        }
    };


    return(
    <div>
        <nav className="navbar">
            <div className="navbar-brand">
                <a href="/" className="navbar-logo">Agada</a>
            </div>
            <div className="navbar-links">
                <a href="/cart" className="navbar-item">Cart</a>
                <a href="/logout" className="navbar-item">Logout</a>
        
            </div>
        </nav>
        <br />
        <div className='search-bar-container'>
            <div>
            <div className="search-title">Search for Medicines / Healthcare Products</div>
                
                <select className='search-input-container' value={selectedShop} onChange={handleShopChange}>
                    <option className='location' value="">-- Select a Shop --</option>
                    {shops.map((shop) => (
                        <option key={shop.shId} value={shop.shId}>
                            {shop.shname}
                        </option>
                    ))}
                </select>
            </div>
            <form onSubmit={handleSearch}>
                <input
                    type="text"
                    value={prodname}
                    onChange={(e) => setProdname(e.target.value)}
                    placeholder="Search for products..."
                    className='search-input'
                />
                <button  className="search-button" type="submit">Search</button>
            </form>
            <ul className='list_medicine'>
                {products.map((inventory) => (
                    <li key={inventory.inv_id}>
                        <h3>{inventory.product.prodname}</h3>
                        <p>{inventory.product.desc}</p>
                        <p>Price: ${inventory.price}</p>
                        <p>Manifacturing Date:{inventory.mfDate}</p>
                        <p>Expiry Date:{inventory.exDate}</p>
                        <div className="quantity-selector">
                        <button onClick={handleDecrement}>-</button>
                        <span>{quantity}</span>
                        <button onClick={handleIncrement}>+</button>

                        <button>Add to Cart</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
        
    </div>)
}