export default function AdminHome()
{
    return(<div>
        <h1>AdminHome page</h1>
    </div>)
}