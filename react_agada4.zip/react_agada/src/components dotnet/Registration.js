import { useEffect, useReducer,useState } from "react";
import { redirect, useNavigate } from 'react-router-dom';
import "../styles/styles.css"
import { type } from "@testing-library/user-event/dist/type";
import axios from 'axios';
import pic3 from '../images/registration2.jpg';
import pic4 from '../images/overview.png';
import "./Registration.css";

const init={
   
    fname:" ",
    lname:"",
    email:"",
    contact:"",
    // city:"100",
    aId:" ",
    address:"",
    rId:"",
    status:"1",
    username:"",
    password:""
}

const initErrors = {
    fname: "",
    lname: "",
    email: "",
    contact: "",
    address: "",
    city:"",
    username: "",
    password: "",
};

const reducer=(state,action)=>{
    switch(action.type){
        case'update':
            return {...state,[action.fld]:action.val};
        case 'reset':
            return init;

        default:
    }
}

const errorReducer = (state, action) => {
    switch (action.type) {
        case 'setError':
            return { ...state, [action.field]: action.error };
        case 'reset':
            return initErrors;
        default:
            return state;
    }
};

export default function Registration(){

    
    const[formData,dispatch] = useReducer(reducer,init);
    const [formErrors, dispatchError] = useReducer(errorReducer, initErrors);
    const navigate = useNavigate();
    const [roles, setRoles] = useState([]);
    const[cities,setCities] = useState([]);
    const [areas, setAreas] = useState([]);
    const [selectedCityId, setSelectedCityId] = useState('');
    const [error, setError] = useState(null);


    const validateField = (name, value) => {
        let error = "";
        switch (name) {
            case "fname":
                if (!value) error = "First Name is required";
                else if (value.length < 2) error = "First name must be at least 2 characters";
                break;

            case "lname":
                if (!value) error = "Last Name is required";
                else if (value.length < 2) error = "Last name must be at least 2 characters";
                break;

            case "email":
                    if (!value) error = "Email is required";
                    else if (!/\S+@\S+\.\S+/.test(value)) error = "Email address is invalid";
                    break;

            case "contact":
                if (!value) error = "Contact is required";
                else if (!/^\d{10}$/.test(value)) error = "Contact must be exactly 10 digits";
                break;

        

            case "city":
                if (!value.city) {
                    error.city = 'City is required';
                } else if (value.city.length < 2) {
                    error.city = 'City name must be at least 2 characters long';
                }
                break;

            case "address":
                    if (!value) error = "Address is required";
                    else if (value.length < 7) error = "Enter Your Full Address";
                    break;

            case "username":
                if (!value) error = "Username is required";
                else if (value.length < 2) error = "Username must be at least 2 characters long";
                break;
            case "password":
                if (!value) {
                    error = "Password is required";
                } else if (!/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(value)) {
                    error = "Password must be 6-12 characters long and contain at least one capital letter, one small letter, and '@'";
                }
                break;

                default:
            }
            dispatchError({type:'setError',field:name,error});
        };


    // const sendData=(e)=>{
    //     e.preventDefault();
    //     const reqoptions={
    //         method:'post',
    //         headers:{ 'Content-Type': 'application/json'},
    //         body:JSON.stringify(formData)
    //     }
    //     fetch("https://localhost:7262/api/UserLogin/SaveUser",reqoptions)
    //     .then(resp => console.log(resp))
    //     .then(data => {
    //         alert('succefully registered')
    //         //console.log('Success:', data);
    //         //navigate('/success'); // Redirect to a success page
    //     })
    //     .catch(error => console.error('Error:', error));
    // }
    const sendData = async (e) => {
        e.preventDefault();
      
        const reqOptions = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        };
      
        try {
          const response = await fetch("https://localhost:7262/api/UserLogin/SaveUser", reqOptions);
      
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
      
          const data = await response.json();
          alert("registered sucessfully");
          console.log('Success:', data);
          // Display success message   or redirect to success page
        } catch (error) {
          console.error('Error:', error);
          // Display error message to user
        }
      };
    // useEffect(()=>{   alert('hello')
          
    //     try {
    //       const response =  fetch(`https://localhost:7262/api/UserLogin/GetAreasByCityId?cityId=${formData.city}`);
    //       const data =  response.json();
    //     //   alert(data)
    //       setAreas(data);
    //       alert(formData.city)
    //     } catch (error) {
    //       console.error('Error fetching areas:', error);
    //     }},[formData.city])
    useEffect(() => {
        // Example hardcoded cities; replace this with API call if needed
        const fetchCities = async () => {
            const response = [
                { id: 101, name: 'Pune' },
                { id: 102, name: 'Mumbai' },
            ];
            setCities(response);
        };

        fetchCities();
    }, []);
      // Fetch areas when a city is selected
      useEffect(() => {
        // alert("1")
        if (selectedCityId) {
            // alert(selectedCityId)
            const fetchAreas = async () => {
                try {
                    const response = await axios.get(`https://localhost:7262/api/UserLogin/GetAreasByCityId?cityId=${selectedCityId}`);
                    //alert(response)
                    console.log(response);        
                    setAreas(response.data);
                } catch (error) {
                    setError('Failed to fetch areas');
                    setAreas([]); // Clear areas if there's an error
                }
            };

            fetchAreas();
        } else {
            setAreas([]);
        }
    }, [selectedCityId]);


    
    // const getAreasWithNames = () => {
        
      
    //       alert('hello')
    //       alert(formData.city)
    //         try {
    //           const response =  fetch(`https://localhost:7262/api/UserLogin/GetAreasByCityId?cityId=${formData.city}`);
    //           const data =  response.json();
    //         //   alert(data)
    //           setAreas(data);
    //           alert(formData.city)
    //         } catch (error) {
    //           console.error('Error fetching areas:', error);
    //         }
    //       };
     return (
        <div   style={{
            backgroundImage: `url(${pic3})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            backgroundColor: '#EBF4FA', // Light sky blue background for the page
        }}>
        <div className="registration-container"
        style={{
            backgroundImage: `url(${pic3})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            backgroundColor: '#FFFFF7', // Light sky blue background for the page
            flex: '0 0 50%',
            
            padding: '20px'
        }}>
            <h1 className="heading">Registration</h1>

            <form action="" className="registration-form">
            <div className="row mb-3">
            <div>
                <br />
                <label>Role: </label>
                <select name="rId" value={formData.rId} onChange={(e)=>{dispatch({type:"update",fld:"rId",val:e.target.value})}}>
                    <option value="">Select Role</option>
                    <option name ="role"value="2">Consumer</option>
                    <option name="role" value="3">Seller</option>
                </select>
                <br />
            </div>
 
            <div className="col">
                <label htmlFor="fname" className="form-label">First Name</label>
                <input type="text" className="form-control" id="fname" name="fname" value={formData.fname} onChange={(e)=>{dispatch({type:"update",fld:"fname",val:e.target.value});validateField('fname', e.target.value);}}/>

                {formErrors.fname && <small className="text-danger">{formErrors.fname}</small>}
            </div>

            <div className="col">
                <label htmlFor="lname" className="form-label">Last Name</label>
                <input type="text" className="form-control" id="lname" name="lname" value={formData.lname} onChange={(e)=>{dispatch({type:"update",fld:"lname",val:e.target.value})}}></input>

                {formErrors.lname && <small className="text-danger">{formErrors.Customer.lname}</small>}
            </div>
            </div>   
            <div className="mb-3">
                <label htmlFor="email" className="form-label">Email</label>
                <input type="text" className="form-control" id="email" name="email" value={formData.email} onChange={(e)=>{dispatch({type:"update",fld:"email",val:e.target.value});validateField('email', e.target.value);}}></input>

                {formErrors.email && <small className="text-danger">{formErrors.email}</small>}
            </div>

            <div className="mb-3">
                <label htmlFor="contact" className="form-label">Contact</label>
                <input type="text" className="form-control" id="contact" name="contact" value={formData.contact} onChange={(e)=>{dispatch({type:"update",fld:"contact",val:e.target.value});validateField('contact', e.target.value);}}></input>

                {formErrors.contact && <small className="text-danger">{formErrors.contact}</small>}
            </div>

            <div>
                    <label>Select City:</label>
                    <select
                        name="city" 
                        value={selectedCityId}
                        onChange={(e) =>{ 
                                         setSelectedCityId(e.target.value)}}
                    >
                        <option value="">Select a city</option>
                        {cities.map((city) => (
                            <option key={city.id} value={city.id}>
                                {city.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label>Select Area:</label>
                    <select  name="aId" value={formData.aId} onChange={(e)=>{dispatch({type:"update",fld:"aId",val:e.target.value})}}>
                        <option value="">Select an area</option>
                        {areas.map((area) => (
                            <option key={area.aId} value={area.aId}>
                                {area.aname}
                            </option>
                        ))}
                    </select>
                </div>


            {/* <div className="mb-3">
            <div>
                <label>City:</label>
                <select name="city" value={formData.city} onChange={(e)=>{dispatch({type:"update",fld:"city",val:e.target.value});getAreasWithNames()}}>
                    <option value="">Select City</option> */}
                    {/* {city.map(role => (
                        <option key={city.id} value={city.id}>{city.name}</option>
                    ))} */}
                    {/* <option value='101'>Pune</option> */}
                    {/* <option value='102'>Mumbai</option>
                </select>
            </div>
            </div> */}

            {/* <div className="mb-3">
             <div>
                <label>Area:</label>
                <select name="area" value={formData.area} onChange={(e)=>{dispatch({type:"update",fld:"area",val:e.target.value})}}>
         
                        <option value=''>Select Area</option>
                        {areas.map(area => (
                        <option key={area.id} value={area.id}>
                            {area.name}
                        </option>
                        ))}
                    
                </select>
             </div>
            </div> */}

            <div className="mb-3">
                <label htmlFor="Address" className="form-label">Address</label>
                <input type="text" className="form-control" id="address" name="address" value={formData.address} onChange={(e)=>{dispatch({type:"update",fld:"address",val:e.target.value});validateField('address', e.target.value);}}></input>

                {formErrors.address && <small className="text-danger">{formErrors.address}</small>}
            </div>
            <div className="mb-3">
                <label htmlFor="username" className="form-label">Username</label>
                <input type="text" className="form-control" id="username" name="username" value={formData.username} onChange={(e)=>{dispatch({type:"update",fld:"username",val:e.target.value});validateField('username', e.target.value);}}></input>

                {formErrors.username && <small className="text-danger">{formErrors.username}</small>}
            </div>

            <div className="mb-3">
                <label htmlFor="password" className="form-label">Password</label>
                <input type="password" className="form-control" id="password" name="password" value={formData.password} onChange={(e)=>{dispatch({type:"update",fld:"password",val:e.target.value});validateField('password', e.target.value);}}></input>

                {formErrors.password && <small className="text-danger">{formErrors.password}</small>}
            </div>

            <button type="submit" className="btn btn-primary mb-3" onClick={(e)=>sendData(e)}>Signup</button>

            </form>
            
            <p>{JSON.stringify(formData)}</p>
        </div>
    </div>
    )

}
