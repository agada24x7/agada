// import React, { useState } from 'react';
// import { Link, Route, Routes } from 'react-router-dom';
// import './SellerHome.css'; // Ensure you import your CSS file
// // import MainSeller from './SellerPage/MainSeller.js';
// // import AddShop from './SellerPage/AddShop.js';
// // import Discounts from './SellerPage/Discounts.js';
// // import AddProduct from './SellerPage/Inventory/AddProduct.js';
// // import DeleteProduct from './SellerPage/Inventory/DeleteProduct.js';
// // import ViewProduct from './SellerPage/Inventory/ViewProduct.js'; // Fixed the name
// // import UpdateProduct from './SellerPage/Inventory/UpdateProduct.js'; // Fixed the import path
// // import Logout from './Logout';




// export default function SellerHome() {
//     const [isDropdownOpen, setIsDropdownOpen] = useState(false);

//     const toggleDropdown = () => {
//         setIsDropdownOpen(!isDropdownOpen);
//     };

//     return (
//         <div className='seller-home-container'>
//             <div className='sidebar'>
//                 <div className="welcome-message">
//                     <h2>Welcome, Seller!</h2>
//                 </div>
//                 <div className='sellernav'>
//                     <nav className='navbar'>
//                         <div className="container-fluid">
//                             <ul className="navbar-nav">
//                                 <li className="nav-item">
//                                     <Link to="/seller/sellerdashboard" className='nav-link px-3'>Home</Link>
//                                 </li>
//                                 <li className='nav-item'>
//                                     <Link to="/seller/addshop" className='nav-link px-3'>Add Shop</Link>
//                                 </li>
//                                 <li className='nav-item'>
//                                     <Link to="/seller/discounts" className='nav-link px-3'>Discount</Link>
//                                 </li>
//                                 <li className="nav-item dropdown">
//                                     <span 
//                                         className='nav-link px-3 dropdown-toggle' 
//                                         onClick={toggleDropdown}
//                                     >
//                                         Manage Inventory
//                                     </span>
//                                     <ul className={`dropdown-menu ${isDropdownOpen ? 'show' : ''}`}>
//                                         <li><Link to="inventory/addproduct" className="dropdown-item">Add Product</Link></li>
//                                         <li><Link to="inventory/deleteproduct" className="dropdown-item">Delete Product</Link></li>
//                                         <li><Link to="inventory/updateproduct" className="dropdown-item">Update Product</Link></li>
//                                         <li><Link to="inventory/viewproduct" className="dropdown-item">View Product</Link></li>
//                                     </ul>
//                                 </li>
//                                 <li className='nav-item'>
//                                     <Link to="logout" className='nav-link px-3'>Logout</Link>
//                                 </li>
//                             </ul>
//                         </div>
//                     </nav>
//                 </div>
//             </div>
//             <div className='content'>
//             {/* <Routes>
//         <Route path="/seller" element={<SellerHome />} >
//                   <Route  path="sellerdashboard" element={<MainSeller />} />
//                   <Route path="addshop" element={<AddShop />} />
//                   <Route path="discounts" element={<Discounts />} />
//                   <Route path="inventory/addproduct" element={<AddProduct />} />
//                   <Route path="inventory/deleteproduct" element={<DeleteProduct />} />
//                   <Route path="inventory/updateproduct" element={<UpdateProduct />} />
//                   <Route path="inventory/viewproduct" element={<ViewProduct />} />
//                   {/* <Route path="/logout" element={<Logout />} /> */}
//         {/* </Route>
//               </Routes> */} 
//             </div>
//         </div>
//     );
// }
import React, { useState, useEffect } from 'react';
import { Link, Outlet } from 'react-router-dom';
import './SellerHome.css';

export default function SellerHome() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [fname, setFname] = useState("");

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  useEffect(() => {
    try {
      const loggedUserData = JSON.parse(localStorage.getItem("LoggedUser"));
      if (loggedUserData && loggedUserData.fname) {
        setFname(loggedUserData.fname);
      }
    } catch (error) {
      console.error("Error retrieving or parsing LoggedUser data:", error);
      // Handle the error appropriately
    }
  }, []);

  return (
    <div className='seller-home-container'>
      <div className='sidebar'>
        <div className="welcome-message">
          <h2>Welcome, {fname}!</h2>
        </div>
        <div className='sellernav'>
          <nav className='navbar'>
            <div className="container-fluid">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link to="sellerdashboard" className='nav-link px-3'>Home</Link>
                </li>
                <li className='nav-item'>
                  <Link to="addshop" className='nav-link px-3'>Add Shop</Link>
                </li>
                <li className='nav-item'>
                  <Link to="discounts" className='nav-link px-3'>Discount</Link>
                </li>
                <li className="nav-item dropdown">
                  <span className='nav-link px-3 dropdown-toggle' onClick={toggleDropdown}>
                    Manage Inventory
                  </span>
                  <ul className={`dropdown-menu ${isDropdownOpen ? 'show' : ''}`}>
                    <li><Link to="inventory/addproduct" className="dropdown-item">Add Product</Link></li>
                    <li><Link to="inventory/deleteproduct" className="dropdown-item">Delete Product</Link></li>
                    <li><Link to="inventory/updateproduct" className="dropdown-item">Update Product</Link></li>
                    <li><Link to="inventory/viewproduct" className="dropdown-item">View Product</Link></li>
                  </ul>
                </li>
                <li className='nav-item'>
                  <Link to="/logout" className='nav-link px-3'>Logout</Link>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
      <div className='content'>
        <Outlet />
      </div>
    </div>
  );
}
