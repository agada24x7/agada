import React, { useReducer, useEffect, useState } from 'react';
import './CSS/AddShop.css';
import img1 from './images/medicalshop1.png';

// Initial state
const loggedUserData = JSON.parse(localStorage.getItem("LoggedUser"));
const uid = loggedUserData.uid;

const initialState = {
  shname: '',
  regNo: '',
  licenseNo: '',
  uid: uid,
  aid: '',
  address: '',
};

// Reducer function
function reducer(state, action) {
  switch (action.type) {
    case 'SET_FIELD':
      return {
        ...state,
        [action.field]: action.value,
      };
    case 'SET_AID':
      return {
        ...state,
        aid: action.value,
      };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

export default function AddShop() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [areas, setAreas] = useState([]);

  // Fetch areas from the backend API
  useEffect(() => {
    fetch('https://localhost:7262/api/UserLogin/GetAreasByCityId?cityId=101')
      .then(response => response.json())
      .then(data => setAreas(data))
      .catch(error => console.error('Error fetching areas:', error));
  }, []);

  const handleChange = (e) => {
    dispatch({
      type: 'SET_FIELD',
      field: e.target.name,
      value: e.target.value,
    });
  };

  const handleAreaChange = (e) => {
    dispatch({
      type: 'SET_AID',
      value: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const req = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    };

    fetch(`http://localhost:8080/shop/saveshop`, req)
      .then(response => response.json())
      .then(data => {
        console.log('Shop saved:', data);
        dispatch({ type: 'RESET' }); // Reset the form after submission
      })
      .catch(error => console.error('Error saving shop:', error));
  };

  return (
    <div
      style={{
        backgroundImage: `url(${img1})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        backgroundColor: '#EBF4FA',
      }}
    >
      <form onSubmit={handleSubmit}
        style={{
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
          backgroundColor: '#EC5800',
          minHeight: '100vh',
        }}
      >
        <div>
          <label>Shop Name:</label>
          <input
            type="text"
            name="shname"
            value={state.shname}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Registration No:</label>
          <input
            type="text"
            name="regNo"
            value={state.regNo}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>License No:</label>
          <input
            type="text"
            name="licenseNo"
            value={state.licenseNo}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Area:</label>
          <select name="aid" onChange={handleAreaChange} value={state.aid}>
            <option value="">Select an area</option>
            {areas.map(area => (
              <option key={area.aId} value={area.aId}>
                {area.aname}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={state.address}
            onChange={handleChange}
          />
        </div>
        <button type="submit">Add Shop</button>
        <div>
          {JSON.stringify(state)}
        </div>
      </form>
    </div>
  );
}
