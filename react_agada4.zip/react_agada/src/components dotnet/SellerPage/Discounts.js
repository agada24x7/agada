export default function Discount()
{
    return(<div>Discount page</div>)
}