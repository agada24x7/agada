import React, { useState, useEffect } from 'react';
import '../CSS/UpdateProduct.css';
const UpdateProduct = ({ userShops }) => {
  const [formData, setFormData] = useState({
    prod_id: '',
    sh_id: '',
    quantity: '',
    price: '',
    discount: '',
    mfg_date: '',
    exp_date: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [shops, setShops] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const loggedUserData = JSON.parse(localStorage.getItem("LoggedUser"));
  const uid = loggedUserData.uid;

  useEffect(() => {
    if (isSubmitted) {
      validateForm();
    }
  }, [formData]);

  useEffect(() => {
    // Fetch shops from the API
    fetch(`http://localhost:8080/shop/getallshops?uid=${uid}`)
      .then(response => response.json())
      .then(data => setShops(data))
      .catch(error => console.error('Error fetching shops:', error));
  }, [uid]);

  useEffect(() => {
    // Fetch products from the API
    alert("in inventory product")
    fetch('http://localhost:8080/inventory/listproducts')
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching products:', error));
      console.log(products);
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.prod_id) newErrors.prod_id = 'Product ID is required';
    if (!formData.sh_id) newErrors.sh_id = 'Shop ID is required';
    if (!formData.quantity || isNaN(formData.quantity)) newErrors.quantity = 'Valid quantity is required';
    if (!formData.price || isNaN(formData.price)) newErrors.price = 'Valid price is required';
    if (!formData.discount || isNaN(formData.discount)) newErrors.discount = 'Valid discount is required';
    if (!formData.mfg_date) newErrors.mfg_date = 'Manufacturing date is required';
    if (!formData.exp_date) newErrors.exp_date = 'Expiry date is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);

    if (validateForm()) {
      // Submit the form data to the server
      console.log('Form data:', formData);
    }
  };

  const handleUpdateClick = (product) => {
    setSelectedProduct(product);
    setFormData({
      prod_id: product.prod_id,
      sh_id: product.sh_id,
      quantity: product.quantity,
      price: product.price,
      discount: product.discount,
      mfg_date: product.mfg_date,
      exp_date: product.exp_date
    });
  };

  return (
    <div>
      <h2>Update Product</h2>
      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Shop ID</th>
            <th>Shop Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Manufacturing Date</th>
            <th>Expiry Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.prodId}>
              <td>{product.product.prodId}</td>
              <td>{product.product.prodname}</td>
              <td>{product.shop.shId}</td>
              <td>{product.shop.shname}</td>
              <td>{product.quantity}</td>
              <td>{product.price}</td>
              <td>{product.discount}</td>
              <td>{product.mfDate}</td>
              <td>{product.exDate}</td>
              <td>
                <button onClick={() => handleUpdateClick(product)}>Update</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedProduct && (
        <form onSubmit={handleSubmit}>
          <div>
            <label>Product ID</label>
            <input
              type="text"
              name="prod_id"
              value={formData.prod_id}
              onChange={handleChange}
            />
            {errors.prod_id && <span>{errors.prod_id}</span>}
          </div>

          <div>
            <label>Shop</label>
            <select
              name="sh_id"
              value={formData.sh_id}
              onChange={handleChange}
            >
              <option value="">Select Shop</option>
              {shops.map((shop) => (
                <option key={shop.sh_id} value={shop.sh_id}>
                  {shop.shname}
                </option>
              ))}
            </select>
            {errors.sh_id && <span>{errors.sh_id}</span>}
          </div>

          <div>
            <label>Quantity</label>
            <input
              type="text"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
            />
            {errors.quantity && <span>{errors.quantity}</span>}
          </div>

          <div>
            <label>Price</label>
            <input
              type="text"
              name="price"
              value={formData.price}
              onChange={handleChange}
            />
            {errors.price && <span>{errors.price}</span>}
          </div>

          <div>
            <label>Discount (%)</label>
            <input
              type="text"
              name="discount"
              value={formData.discount}
              onChange={handleChange}
            />
            {errors.discount && <span>{errors.discount}</span>}
          </div>

          <div>
            <label>Manufacturing Date</label>
            <input
              type="date"
              name="mfg_date"
              value={formData.mfg_date}
              onChange={handleChange}
            />
            {errors.mfg_date && <span>{errors.mfg_date}</span>}
          </div>

          <div>
            <label>Expiry Date</label>
            <input
              type="date"
              name="exp_date"
              value={formData.exp_date}
              onChange={handleChange}
            />
            {errors.exp_date && <span>{errors.exp_date}</span>}
          </div>

          <button type="submit">Update Product</button>
        </form>
      )}
    </div>
  );
};

export default UpdateProduct;
