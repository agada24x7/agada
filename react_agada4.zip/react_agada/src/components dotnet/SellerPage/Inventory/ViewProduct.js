import React, { useState, useEffect } from 'react';
import '../CSS/ViewProduct.css'; // Assuming you have a separate CSS file for styling

const ViewProduct = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch products from the API
    fetch('http://localhost:8080/inventory/listproducts')
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  return (
    <div className="view-product-container">
      <h2>Inventory Products</h2>
      <table className="product-table">
        <thead>
          <tr>
            <th>Inventory ID</th>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Shop ID</th>
            <th>Shop Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Manufacturing Date</th>
            <th>Expiry Date</th>
          </tr>
        </thead>
        <tbody>
          {products.length > 0 ? (
            products.map(product => (
              <tr key={product.product.prodId}>
                <td>{product.invId}</td>
                <td>{product.product.prodId}</td>
                <td>{product.product.prodname}</td>
                <td>{product.shop.shId}</td>
                <td>{product.shop.shname}</td>
                <td>{product.quantity}</td>
                <td>{product.price}</td>
                <td>{product.discount}</td>
                <td>{product.mfDate}</td>
                <td>{product.exDate}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="10">No products available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ViewProduct;
