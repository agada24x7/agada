import React, { useState, useEffect } from 'react';

const AddProductForm = ({ userShops }) => {
  const [formData, setFormData] = useState({
    prod_id: '',
    sh_id: '',
    quantity: '',
    price: '',
    discount: '',
    mfg_date: '',
    exp_date: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [shops, setShops] = useState([]);
  const loggedUserData = JSON.parse(localStorage.getItem("LoggedUser"));
  const uid = loggedUserData.uid;
  useEffect(() => {
    if (isSubmitted) {
      validateForm();
    }
  }, [formData]);
  useEffect(() => {
    // Fetch shops from the API
    fetch(`http://localhost:8080/shop/getallshops?uid=${uid}`)
      .then(response => response.json())
      .then(data => setShops(data))
      .catch(error => console.error('Error fetching shops:', error));
  }, [uid]);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.prod_id) newErrors.prod_id = 'Product ID is required';
    if (!formData.sh_id) newErrors.sh_id = 'Shop ID is required';
    if (!formData.quantity || isNaN(formData.quantity)) newErrors.quantity = 'Valid quantity is required';
    if (!formData.price || isNaN(formData.price)) newErrors.price = 'Valid price is required';
    if (!formData.discount || isNaN(formData.discount)) newErrors.discount = 'Valid discount is required';
    if (!formData.mfg_date) newErrors.mfg_date = 'Manufacturing date is required';
    if (!formData.exp_date) newErrors.exp_date = 'Expiry date is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);

    if (validateForm()) {
      // Submit the form data to the server
      console.log('Form data:', formData);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Product ID</label>
        <input
          type="text"
          name="prod_id"
          value={formData.prod_id}
          onChange={handleChange}
        />
        {errors.prod_id && <span>{errors.prod_id}</span>}
      </div>

      <div>
        <label>Shop</label>
        <select
          name="sh_id"
          value={formData.sh_id}
          onChange={handleChange}
        >
          <option value="">Select Shop</option>
          {shops.map((shop) => (
            <option key={shop.sh_id} value={shop.sh_id}>
              {shop.shname}
            </option>
          ))}
        </select>
        {errors.sh_id && <span>{errors.sh_id}</span>}
      </div>

      <div>
        <label>Quantity</label>
        <input
          type="text"
          name="quantity"
          value={formData.quantity}
          onChange={handleChange}
        />
        {errors.quantity && <span>{errors.quantity}</span>}
      </div>

      <div>
        <label>Price</label>
        <input
          type="text"
          name="price"
          value={formData.price}
          onChange={handleChange}
        />
        {errors.price && <span>{errors.price}</span>}
      </div>

      <div>
        <label>Discount (%)</label>
        <input
          type="text"
          name="discount"
          value={formData.discount}
          onChange={handleChange}
        />
        {errors.discount && <span>{errors.discount}</span>}
      </div>

      <div>
        <label>Manufacturing Date</label>
        <input
          type="date"
          name="mfg_date"
          value={formData.mfg_date}
          onChange={handleChange}
        />
        {errors.mfg_date && <span>{errors.mfg_date}</span>}
      </div>

      <div>
        <label>Expiry Date</label>
        <input
          type="date"
          name="exp_date"
          value={formData.exp_date}
          onChange={handleChange}
        />
        {errors.exp_date && <span>{errors.exp_date}</span>}
      </div>

      <button type="submit">Add Product</button>
    </form>
  );
};

export default AddProductForm;
