import React, { useState, useEffect } from 'react';
import '../CSS/ViewProduct.css'; // Assuming you have a separate CSS file for styling

const DeleteProduct = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch products from the API
    fetch('http://localhost:8080/inventory/listproducts')
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  const handleDelete = (prodId) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      // Perform the delete action
      fetch(`http://localhost:8080/inventory/deleteproduct?prodId=${prodId}`, {
        method: 'DELETE',
      })
        .then(response => {
          if (response.ok) {
            // Remove the deleted product from the state
            setProducts(products.filter(product => product.product.prodId !== prodId));
            alert('Product deleted successfully');
          } else {
            alert('Failed to delete the product');
          }
        })
        .catch(error => console.error('Error deleting product:', error));
    }
  };

  return (
    <div className="view-product-container">
      <h2>Delete Products</h2>
      <table className="product-table">
        <thead>
          <tr>
            <th>Inventory ID</th>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Shop ID</th>
            <th>Shop Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Manufacturing Date</th>
            <th>Expiry Date</th>
            <th>Action</th> {/* Added Action column */}
          </tr>
        </thead>
        <tbody>
          {products.length > 0 ? (
            products.map(product => (
              <tr key={product.product.prodId}>
                <td>{product.invId}</td>
                <td>{product.product.prodId}</td>
                <td>{product.product.prodname}</td>
                <td>{product.shop.shId}</td>
                <td>{product.shop.shname}</td>
                <td>{product.quantity}</td>
                <td>{product.price}</td>
                <td>{product.discount}</td>
                <td>{product.mfDate}</td>
                <td>{product.exDate}</td>
                <td>
                  <button 
                    className="delete-button" 
                    onClick={() => handleDelete(product.product.prodId)}
                  >
                    Delete
                  </button>
                </td> {/* Added delete button */}
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="11">No products available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DeleteProduct;
