import { useState, useEffect } from 'react';
import './CSS/MainSeller.css';
import img2 from './images/medicalshop2.jpg';

export default function MainSeller() {
  const [shops, setShops] = useState([]);
  const loggedUserData = JSON.parse(localStorage.getItem("LoggedUser"));
  const uid = loggedUserData.uid;

  useEffect(() => {
    // Fetch shops from the API
    fetch(`http://localhost:8080/shop/getallshops?uid=${uid}`)
      .then(response => response.json())
      .then(data => setShops(data))
      .catch(error => console.error('Error fetching shops:', error));
  }, [uid]);

  return (
    <div className="background-container">
      <div className="content-wrapper">
        <h1>Welcome back!</h1>
        <div id="shops-container">
          {shops.length > 0 ? (
            shops.map((shop) => (
              <div className="shop-block" key={shop.id}>
                <h2>{shop.shname}</h2>
                <p>{shop.address}</p>
                <button onClick={() => handleEdit(shop)}>Edit</button>
                <button onClick={() => handleDelete(shop.shId)}>Delete</button>
              </div>
            ))
          ) : (
            <div className="no-shops-block">
              <h2>No shops registered yet!</h2>
              <p><a href="/addshop">Click here to add your first shop</a></p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  function handleEdit(shop) {
    // Handle shop edit logic here
    console.log('Editing shop:', shop);
  }

  function handleDelete(shopId) {
    console.log('Attempting to delete shop with ID:', shopId);
  
    fetch(`http://localhost:8080/shop/deleteshop?shId=${shopId}`, { 
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    })
      .then(response => {
        if (response.ok) {
          console.log('Shop deleted successfully');
          // Update the state directly by filtering out the deleted shop
          setShops(prevShops => prevShops.filter(shop => shop.shId !== shopId));
        } else {
          return response.text().then(text => {
            console.error('Failed to delete shop:', response.status, response.statusText, text);
          });
        }
      })
      .catch(error => {
        console.error('Error deleting shop:', error);
      });
  }
  


}

