 // import React, { useState } from 'react';
// import { FaEye, FaEyeSlash } from 'react-icons/fa';
// import { Link, useNavigate } from 'react-router-dom';
// import { login } from './slice';
// import { useDispatch } from 'react-redux';
// //import '../components/CSS/style.css';
// import pic from '../images/vision.png'

// function LoginPage() {
//     const [username, setUsername] = useState('');
//     const [password, setPassword] = useState('');
//     const [errors, setError] = useState({});
//     const [successMessage, setSuccessMessage] = useState('');
//     const navigate = useNavigate();
//     const [passwordType, setPasswordType] = useState('password');
//     const reduxAction=useDispatch();
//     const togglePassword = () => {
//         setPasswordType(passwordType === 'password' ? 'text' : 'password');
//     };

//     const validate = () => {
//         let tempErr = {};
//         if (!username) tempErr.username = "Username is required";
//         if (!password) tempErr.password = "Password is required";
//         setError(tempErr);
//         return Object.keys(tempErr).length === 0;
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         setError({});
//         setSuccessMessage('');

//         if (validate()) {
//             console.log('Username:', username);
//             console.log('Password:', password);

//             try {
//                 const response = await fetch('https://localhost:7262/api/UserLogin/CheckLogin', {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                     body: JSON.stringify({ Username: username, Password: password }),
//                 });

//                 const data = await response.json();
//                 console.log('Response data:', data);

//                 if (response.ok) {
//                     reduxAction(login())
//                     setSuccessMessage('Login successful! Redirecting...');
//                     setTimeout(() => {
                        
//                         switch (data.rid) {
//                             case 1:
//                                 navigate('/AdminHome');
//                                 break;
//                             case 2:
//                                 navigate('/ConsumerHome');
//                                 break;
//                             case 3:
//                                 navigate('/SellerHome');
//                                 break;
//                             default:
//                                 setError({ general: data.message || 'Login failed' });
//                                 break;
//                         }
//                     }, 2000);
//                 } else {
//                     setError({ general: data.message || 'Login failed ' });
//                 }
//             } catch (error) {
//                 console.error('Error:', error);
//                 setError({ general: "An unexpected error occurred" });
//             } finally {
//                 setUsername('');
//                 setPassword('');
//             }
//         }
//     };

//     return (
//         <div id='login' className="d-flex align-items-center justify-content-center vh-100"
//         style={{
//             backgroundImage: `url(${pic})`,
//             backgroundSize: 'cover',
//             backgroundPosition: 'center',
//             backgroundAttachment: 'fixed', // Prevents the image from moving
//         }}>
//             <div className="card shadow p-4 w-25">
//                 <h2 className="text-center mb-4">Login</h2>
//                 <form onSubmit={handleSubmit}>
//                     <div className="form-group mb-3">
//                         <label htmlFor="username" className="form-label">Username</label>
//                         <div className="input-group">
//                             <span className="input-group-text"><i className="bi bi-person-fill"></i></span>
//                             <input
//                                 type="text"
//                                 className={`form-control ${errors.username ? 'is-invalid' : ''}`}
//                                 placeholder="Enter your username"
//                                 name="username"
//                                 id="username"
//                                 value={username}
//                                 onChange={(e) => setUsername(e.target.value)}
//                             />
//                             {errors.username && <div className="invalid-feedback">{errors.username}</div>}
//                         </div>
//                     </div>

//                     <div className="form-group mb-3">
//                         <label htmlFor="password" className="form-label">Password</label>
//                         <div className="input-group">
//                             <span className="input-group-text"><i className="bi bi-lock-fill"></i></span>
//                             <input
//                                 type={passwordType}
//                                 className={`form-control ${errors.password ? 'is-invalid' : ''}`}
//                                 placeholder="Enter your password"
//                                 name="password"
//                                 id="password"
//                                 value={password}
//                                 onChange={(e) => setPassword(e.target.value)} />
//                             <span className="input-group-text">
//                                 {passwordType === 'password' ? (
//                                     <FaEye onClick={togglePassword} />
//                                 ) : (
//                                     <FaEyeSlash onClick={togglePassword} />
//                                 )}
//                             </span>
//                             {errors.password && <div className="invalid-feedback">{errors.password}</div>}
//                         </div>
//                     </div>

//                     {errors.general && <div className="alert alert-danger">{errors.general}</div>}
//                     {successMessage && <div className="alert alert-success">{successMessage}</div>}

//                     <div className="d-grid">
//                         <button type="submit" className="btn btn-primary">Login</button>
//                     </div>
//                 </form>
//                 <div className="text-center mt-3">
//                     <Link to="/forgot-password" className="text-muted">Forgot Password?</Link>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default LoginPage;
import React, { useState } from 'react';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import { login } from './slice';
import { useDispatch } from 'react-redux';
import pic from '../images/vision.png';

function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setError] = useState({});
    const [successMessage, setSuccessMessage] = useState('');
    const navigate = useNavigate();
    const [passwordType, setPasswordType] = useState('password');
    const reduxAction = useDispatch();

    const togglePassword = () => {
        setPasswordType(passwordType === 'password' ? 'text' : 'password');
    };

    const validate = () => {
        let tempErr = {};
        if (!username) tempErr.username = "Username is required";
        if (!password) tempErr.password = "Password is required";
        setError(tempErr);
        return Object.keys(tempErr).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError({});
        setSuccessMessage('');

        if (validate()) {
            console.log('Username:', username);
            console.log('Password:', password);

            try {
                const response = await fetch('https://localhost:7262/api/UserLogin/CheckLogin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ Username: username, Password: password }),
                });

                const data = await response.json();
                console.log('Response data:', data);

                if (response.ok) {
                    reduxAction(login());
                    localStorage.setItem("LoggedUser", JSON.stringify(data));//localStorage can save only string..
                    setSuccessMessage('Login successful! Redirecting...');
                    setTimeout(() => {
                        switch (data.rid) {
                            case 1:
                                navigate('/AdminHome');
                                break;
                            case 2:
                                navigate('/ConsumerHome');
                                break;
                            case 3:
                                navigate('/sellerhome');
                                break;
                            default:
                                setError({ general: data.message || 'Login failed' });
                                break;
                        }
                    }, 2000);
                } else {
                    setError({ general: data.message || 'Login failed ' });
                }
            } catch (error) {
                console.error('Error:', error);
                setError({ general: "An unexpected error occurred" });
            } finally {
                setUsername('');
                setPassword('');
            }
        }
    };

    return (
      
        <div id='login' className="d-flex align-items-center justify-content-center vh-100"
            style={{
                backgroundImage: `url(${pic})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundAttachment: 'fixed',
                backgroundColor: '#87CEFA', // Light sky blue background for the page
                marginTop:'-40px'
            }}>
            <div className="card shadow p-4 w-25" style={{ backgroundColor: '#e3f2fd', border: '1px solid #b0c4de' }}>
                <h2 className="text-center mb-4" style={{ color: '#007bff' }}>Login</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-3">
                        <label htmlFor="username" className="form-label" style={{ color: '#007bff' }}>Username</label>
                        <div className="input-group">
                            <span className="input-group-text" style={{ backgroundColor: '#007bff', color: '#fff' }}>
                                <i className="bi bi-person-fill"></i>
                            </span>
                            <input
                                type="text"
                                className={`form-control ${errors.username ? 'is-invalid' : ''}`}
                                placeholder="Enter your username"
                                name="username"
                                id="username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                            />
                            {errors.username && <div className="invalid-feedback">{errors.username}</div>}
                        </div>
                    </div>

                    <div className="form-group mb-3">
                        <label htmlFor="password" className="form-label" style={{ color: '#007bff' }}>Password</label>
                        <div className="input-group">
                            <span className="input-group-text" style={{ backgroundColor: '#007bff', color: '#fff' }}>
                                <i className="bi bi-lock-fill"></i>
                            </span>
                            <input
                                type={passwordType}
                                className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                                placeholder="Enter your password"
                                name="password"
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)} />
                            <span className="input-group-text" style={{ backgroundColor: '#007bff', color: '#fff' }}>
                                {passwordType === 'password' ? (
                                    <FaEye onClick={togglePassword} />
                                ) : (
                                    <FaEyeSlash onClick={togglePassword} />
                                )}
                            </span>
                            {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                        </div>
                    </div>

                    {errors.general && <div className="alert alert-danger">{errors.general}</div>}
                    {successMessage && <div className="alert alert-success">{successMessage}</div>}

                    <div className="d-grid">
                        <button type="submit" className="btn btn-primary" style={{ backgroundColor: '#007bff' }}>Login</button>
                    </div>
                </form>
                <div className="text-center mt-3">
                    <Link to="/forgot-password" className="text-muted">Forgot Password?</Link>
                </div>
            </div>
        </div>
    
    );
}

export default LoginPage;
